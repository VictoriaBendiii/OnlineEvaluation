<?php include('connection.php');
        if(!isset($_SESSION['username'])){
        header('Location: login.php');
    }
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SLU Peer Evaluation | Archive</title>
    <link rel="stylesheet" href="css/styles.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="css/images/slogo.png">
    <link rel="favicon" href="assets/images/favicon.png">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css"> 
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen"> 
	<link rel="stylesheet" href="assets/css/style.css">
    <link rel='stylesheet' id='camera-css'  href='assets/css/camera.css' type='text/css' media='all'>
        <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    </head>
    
    <body>
        
        <div class="wrapper">
            <header>
                <nav style="z-index: 1000; background-color: RGBA(92,115,139, 0.6);">
                    <div class="menu-icon">
                        <i class="fa fa-bars fa-2x"></i>
                    </div>
					<img src="css/images/slogo.png" style="height: 45px; width: 36px; position: fixed; top: 10px; left: 10px;">
                    <div class="logo">&emsp;SLU Peer Evaluation</div>
                     <div class="menu">
                        <ul>
                            <li style="color: white; font-size: 20px; "><a style="outline: 0;" href="#" onclick="websitenav();">
                            <?php 
							$username = $_SESSION['username'];
							$query = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username';");
    
							while($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
							$profilepicture = $row['profilepicture'];
							$first = $row['firstname'];
							$last = $row['lastname'];
							echo "<img src='images/profilepictures/$profilepicture' class='navpic' alt='profile picture'>";
							}
							?> </a></li>
                        </ul>
                    </div>
                </nav>

				<p id="title">Archived Classes</p>
                 <div class="container">
    <div class="row" style="padding-top: 95px;">
					<?php
                $target_name = array();
                $user = mysqli_real_escape_string($conn, $_SESSION['username']);
                $sql = "select * from user_course join users using(id) join course using(courseCode) where users.username ='$user' AND course.status='Archived';";
                $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) != null) {
                        // output data of each row
                        
                        while($row = mysqli_fetch_assoc($result)) {
                             $_SESSION['courseCode'] = $row['courseCode'];  
							 $_SESSION['courseName'] = $row['courseName']; 
                            echo "<div class='col-md-3'><div class='grey-box-icon' style='height: 260px;'> <div class='icon-box-top grey-box-icon-pos'>
										<br>
									<form action='teacherForm.php' method='post'>
										<img src='assets/images/1.PNG' alt='' style='width: 100px; height: auto;' />
                                    </div><button type='submit' class='btn-link'><div style='position: relative; top: -40px;'><h4>&nbsp; <div> ".$_SESSION["courseCode"].  "<br>" . $_SESSION["courseName"]." <br></h4> </button>
                                    <input type='hidden' name='course' value='".$row['courseCode']."'>
                                    <input type='hidden' name='courseCode' value='".$row['courseCode']."'>
                                    <input type='hidden' name='courseName' value='".$row['courseName']."'>
                                    </form>
						</div>  
					</div>";
						}
                    } 
    ?>
  
      </div>
    
    </div>
    </header>
        <!-- Profile Modal -->
          <div class="modal fade" id="profile" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
                      <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                          <div class="modal-header" style="background-color: #3d84e6">
                            <h5 class="modal-title" id="exampleModalLongTitle" style="text-align: center; color: white; font-size: 2em">PROFILE</h5>
                          </div>
                          <div class="modal-body" style="text-align: center; font-size: 1.3em;">
                            To add a class, please fill in the form <br> indicated below.
                              <div class="form-group">
                                  <label for="code"></label>
                                  <input type="text" class="form-control" name="code" placeholder="Course Code" required>
                              </div>
                              
                              
                              <div class="form-group">
                                  <label for="name"></label>
                                  <input type="text" class="form-control" name="name" placeholder="Course Name" required>
                              </div>
                              
                              <div class="form-group">
                                  <label for="desc"></label>
                                  <input type="text" class="form-control" name="num" placeholder="Course Number" required>
                              </div>    
                              
                               <div class="form-group">
                                  <label for="sched"></label>
                                  <input type="text" class="form-control" name="sched" placeholder="Schedule" required>
                              </div>             
                              
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name ="add">Add class</button>
                          </div>
                        </div>
                      </div>
                </div>
	
    <script src="assets/js/modernizr-latest.js"></script> 
	<script type='text/javascript' src='assets/js/jquery.min.js'></script>
    <script type='text/javascript' src='assets/js/fancybox/jquery.fancybox.pack.js'></script>
    
    <script type='text/javascript' src='assets/js/jquery.mobile.customized.min.js'></script>
    <script type='text/javascript' src='assets/js/jquery.easing.1.3.js'></script> 
    <script type='text/javascript' src='assets/js/camera.min.js'></script> 
    <script src="assets/js/bootstrap.min.js"></script> 
	<script src="assets/js/custom.js"></script>
    
            <?php
    function prompt($prompt_msg){
        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");
        $answer = "<script type='text/javascript'> document.write(answer); </script>";
        return($answer);
    }
            ?>  

            <script type="text/javascript">
        
        $(function() {
           var welcomeSection = $('.welcome-section'),
               enterButton = welcomeSection.find('.enter-button');
            
            setTimeout(function() {
                welcomeSection.removeClass('content-hidden');
            },800);
            
            enterButton.on('click', function(e){
               e.preventDefault();
                welcomeSection.addClass('content-hidden').fadeOut();
            });
        });
            
        </script>
        
        <script type="text/javascript">
        $(document).ready(function(){
            $(".menu-icon").on("click", function(){
                $("nav ul").toggleClass("showing");
            });
        });
            
        $(window).on("scroll", function(){
            if($(window).scrollTop()) {
                $('nav').addClass('black');
            } else {
                $('nav').removeClass('black');
            }
        })    
            
        </script>
        <div id="pictureNavigation" style="display: none;">
		<ul>
		<li><a href="teacherpage.php"><img src='images/class.png' class='picnavicon'> Classes</a></li>
		<li><a href="profteacher.php"><img src='images/profile.png' class='picnavicon'> Profile</a></li>
		<li><a href="signout.php"><img src='images/logout.png' class='picnavicon'> Log out</a></li>
		</ul>
	  </div>
    <script src="assets/js/modernizr-latest.js"></script> 
	  <script type='text/javascript' src='assets/js/jquery.min.js'></script>
    <script type='text/javascript' src='assets/js/fancybox/jquery.fancybox.pack.js'></script>
    
    <script type='text/javascript' src='assets/js/jquery.mobile.customized.min.js'></script>
    <script type='text/javascript' src='assets/js/jquery.easing.1.3.js'></script> 
    <script type='text/javascript' src='assets/js/camera.min.js'></script> 
    <script src="assets/js/bootstrap.min.js"></script> 
	   <script src="assets/js/custom.js"></script>
            
    <script type="text/javascript">
        $(document).ready(function(){
			$(document).mouseup(function(e){
				var subject = $("#pictureNavigation"); 
        if(e.target.id != subject.attr('id') && !subject.has(e.target).length){
            subject.fadeOut();
				}
			});
		});
		
        $(function() {
           var welcomeSection = $('.welcome-section'),
               enterButton = welcomeSection.find('.enter-button');
            
            setTimeout(function() {
                welcomeSection.removeClass('content-hidden');
            },800);
            
            enterButton.on('click', function(e){
               e.preventDefault();
                welcomeSection.addClass('content-hidden').fadeOut();
            });
        });
            
        </script>
        
        <script type="text/javascript">
        
        $(document).ready(function(){
            $(".menu-icon").on("click", function(){
                $("nav ul").toggleClass("showing");
            });
        });
            
        $(window).on("scroll", function(){
            if($(window).scrollTop()) {
                $('nav').addClass('black');
            } else {
                $('nav').removeClass('black');
            }
        })    
		
		function websitenav(){
			var x = document.getElementById("pictureNavigation");
			if (x.style.display === "none") {
				x.style.display = "block";
			} else {
				x.style.display = "none";
			}
		}
 
        </script>
		</div>
        </div>
        
    </body>
</html>
